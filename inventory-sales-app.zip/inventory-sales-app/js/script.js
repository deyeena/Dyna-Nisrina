document.addEventListener('DOMContentLoaded', () => {
    let inventory = [];
    let totalSales = 0;

    const itemForm = document.getElementById('itemForm');
    const salesForm = document.getElementById('salesForm');
    const inventoryBody = document.getElementById('inventoryBody');
    const saleItemSelect = document.getElementById('saleItem');
    const totalSalesSpan = document.getElementById('totalSales');

    // Tambah Barang
    itemForm.addEventListener('submit', (e) => {
        e.preventDefault();
        
        const name = document.getElementById('itemName').value;
        const stock = parseInt(document.getElementById('itemStock').value);
        const price = parseInt(document.getElementById('itemPrice').value);

        const item = {
            id: Date.now(),
            name,
            stock,
            price
        };

        inventory.push(item);
        updateInventoryTable();
        updateSalesDropdown();
        itemForm.reset();
    });

    // Proses Penjualan
    salesForm.addEventListener('submit', (e) => {
        e.preventDefault();
        
        const selectedItemId = parseInt(saleItemSelect.value);
        const quantity = parseInt(document.getElementById('saleQuantity').value);
        
        const item = inventory.find(i => i.id === selectedItemId);
        
        if (item && item.stock >= quantity) {
            item.stock -= quantity;
            totalSales += quantity * item.price;
            updateInventoryTable();
            updateTotalSales();
            salesForm.reset();
        } else {
            alert('Stok tidak cukup!');
        }
    });

    // Update Tabel Persediaan
    function updateInventoryTable() {
        inventoryBody.innerHTML = '';
        inventory.forEach((item, index) => {
            const row = document.createElement('tr');
            row.innerHTML = `
                <td>${index + 1}</td>
                <td>${item.name}</td>
                <td>${item.stock}</td>
                <td>Rp ${item.price.toLocaleString()}</td>
                <td><button class="delete-btn" onclick="deleteItem(${item.id})">Hapus</button></td>
            `;
            inventoryBody.appendChild(row);
        });
    }

    // Update Dropdown Penjualan
    function updateSalesDropdown() {
        saleItemSelect.innerHTML = '<option value="">Pilih Barang</option>';
        inventory.forEach(item => {
            const option = document.createElement('option');
            option.value = item.id;
            option.textContent = `${item.name} (Stok: ${item.stock})`;
            saleItemSelect.appendChild(option);
        });
    }

    // Update Total Penjualan
    function updateTotalSales() {
        totalSalesSpan.textContent = totalSales.toLocaleString();
    }

    // Hapus Barang
    window.deleteItem = function(id) {
        inventory = inventory.filter(item => item.id !== id);
        updateInventoryTable();
        updateSalesDropdown();
    }
});