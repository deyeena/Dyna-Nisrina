# Aplikasi Persediaan dan Penjualan

Aplikasi sederhana untuk mengelola persediaan barang dan mencatat penjualan.

## Fitur
1. Menambah barang baru ke persediaan
2. Melihat daftar persediaan
3. Menghapus barang dari persediaan
4. Mencatat penjualan
5. Melihat total penjualan

## Cara Menjalankan
1. Clone repository ini
2. Buka file `index.html` di browser
3. Mulai menggunakan aplikasi

## Teknologi
- HTML5
- CSS3
- JavaScript (ES6)