<?php
include 'config.php';

$data = json_decode(file_get_contents("php://input"), true);
$name = $data['name'];
$quantity = $data['quantity'];
$price = $data['price'];

$stmt = $pdo->prepare("INSERT INTO items (name, quantity, price) VALUES (?, ?, ?)");
$stmt->execute([$name, $quantity, $price]);

echo json_encode(['message' => 'Item added successfully']);
?>