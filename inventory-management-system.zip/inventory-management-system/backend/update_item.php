<?php
include 'config.php';

$data = json_decode(file_get_contents("php://input"), true);
$id = $data['id'];
$name = $data['name'];
$quantity = $data['quantity'];
$price = $data['price'];

$stmt = $pdo->prepare("UPDATE items SET name = ?, quantity = ?, price = ? WHERE id = ?");
$stmt->execute([$name, $quantity, $price, $id]);

echo json_encode(['message' => 'Item updated successfully']);
?>