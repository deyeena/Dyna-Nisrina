document.addEventListener('DOMContentLoaded', loadItems);

function loadItems() {
    fetch('backend/get_items.php')
        .then(response => response.json())
        .then(data => {
            const tbody = document.getElementById('itemsBody');
            tbody.innerHTML = '';
            data.forEach((item, index) => {
                const row = `
                    <tr>
                        <td>${index + 1}</td>
                        <td>${item.name}</td>
                        <td>${item.quantity}</td>
                        <td>$${item.price}</td>
                        <td>
                            <button class="edit" onclick="showEditForm(${item.id}, '${item.name}', ${item.quantity}, ${item.price})">Edit</button>
                            <button class="delete" onclick="deleteItem(${item.id})">Delete</button>
                        </td>
                    </tr>`;
                tbody.innerHTML += row;
            });
        });
}

function showAddForm() {
    document.getElementById('formTitle').textContent = 'Add Item';
    document.getElementById('itemId').value = '';
    document.getElementById('name').value = '';
    document.getElementById('quantity').value = '';
    document.getElementById('price').value = '';
    document.getElementById('itemForm').style.display = 'block';
}

function showEditForm(id, name, quantity, price) {
    document.getElementById('formTitle').textContent = 'Edit Item';
    document.getElementById('itemId').value = id;
    document.getElementById('name').value = name;
    document.getElementById('quantity').value = quantity;
    document.getElementById('price').value = price;
    document.getElementById('itemForm').style.display = 'block';
}

function hideForm() {
    document.getElementById('itemForm').style.display = 'none';
}

document.getElementById('addEditForm').addEventListener('submit', function(e) {
    e.preventDefault();
    const id = document.getElementById('itemId').value;
    const name = document.getElementById('name').value;
    const quantity = document.getElementById('quantity').value;
    const price = document.getElementById('price').value;

    const data = { id, name, quantity, price };
    const url = id ? 'backend/update_item.php' : 'backend/add_item.php';

    fetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
    })
    .then(response => response.json())
    .then(() => {
        hideForm();
        loadItems();
    });
});

function deleteItem(id) {
    if (confirm('Are you sure you want to delete this item?')) {
        fetch('backend/delete_item.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ id })
        })
        .then(response => response.json())
        .then(() => loadItems());
    }
}