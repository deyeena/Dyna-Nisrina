// script.js
document.addEventListener("DOMContentLoaded", function() {
    console.log("Halaman telah dimuat!");
    // Bisa ditambahkan fungsi interaktif seperti konfirmasi atau validasi
});