<?php
include 'config.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $product_name = $_POST['product_name'];
    $price = $_POST['price'];
    $description = $_POST['description'];

    $sql = "INSERT INTO products (product_name, price, description) VALUES (?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sds", $product_name, $price, $description);

    if ($stmt->execute()) {
        echo "Produk berhasil ditambahkan!";
    } else {
        echo "Error: " . $conn->error;
    }

    $stmt->close();
    $conn->close();
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Tambah Produk</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <h1>Tambah Produk Baru</h1>
    <form method="POST" action="add_product.php">
        <label>Nama Produk:</label><br>
        <input type="text" name="product_name" required><br>
        <label>Harga:</label><br>
        <input type="number" step="0.01" name="price" required><br>
        <label>Deskripsi:</label><br>
        <textarea name="description"></textarea><br>
        <button type="submit">Tambah</button>
    </form>
    <a href="index.php">Kembali ke Daftar Produk</a>
</body>
</html>